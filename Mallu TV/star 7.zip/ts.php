<?php
error_reporting(0);
$opts = [
    "http" => [
        "method" => "GET",
        "header" => "User-Agent: REDLINECLIENT RED360 V0.1.49" 
    ]
];

$cx = stream_context_create($opts);

header("content-type: video/mp2t");
header("pragma: no-cache");
$ts = $_GET['ts'];
$maintoken="dG9rZW49UkVEX3Zxb2pyb0JFRjViR0p2WFlSRGRWM3c9PSwxNjE5Nzc0NjM0LjE3NDM4MDA1NDk=";
$tok=base64_decode($maintoken);
$rey="aHR0cDovL3JleWFuY2UwLndlYmQucHJvL21wLnBocC8=";
$pxy= base64_decode($rey);
$url = $pxy.$ts."?".$tok;
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"User-Agent: exoplayer\r\n"
  )
);
$context = stream_context_create($opts);
$e = file_get_contents($url, false, $context);
echo $e;
?>