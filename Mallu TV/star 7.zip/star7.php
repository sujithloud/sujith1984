<?php
error_reporting(0);
header("content-type: application/vnd.apple.mpegurl");
header("pragma: no-cache");
header("Connection: keep-alive");
$id = $_GET['id'];
$opts = [
    "http" => [
        "method" => "GET",
        "header" => "User-Agent: REDLINECLIENT RED360 V0.1.49" 
    ]
];

$cx = stream_context_create($opts);

$json = json_decode(file_get_contents("starzz.json"), true);

foreach($json["channels_list"] as $v) {
	if($v['id'] == $id) {
		$url = $v['link'];
	}
}
$maintoken="dG9rZW49UkVEX3Zxb2pyb0JFRjViR0p2WFlSRGRWM3c9PSwxNjE5Nzc0NjM0LjE3NDM4MDA1NDk=";
$tok=base64_decode($maintoken);
$burl = $url;
$rey="aHR0cDovL3JleWFuY2UwLndlYmQucHJvL21wLnBocC8=";
$pxy= base64_decode($rey);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $burl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$html = curl_exec($ch);
$baselink = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
curl_close($ch);
$burl = $pxy.$baselink;
$blink = preg_replace("/(?=index).*/", "", $burl);
$elink = preg_replace("/(?=index).*/", "", $baselink);
$flink = $blink."tracks-v1a1/mono.m3u8?".$tok;
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"User-Agent: REDLINECLIENT RED360 V0.1.49"
  )
);
$context = stream_context_create($opts);
$e = file_get_contents($flink, false, $context);
$f = preg_replace("/(?<=ts).*/", "", $e);
$g = preg_replace("/(?=2022\/).*ts/", "http://domain/ts.php?ts=".$elink."tracks-v1a1/"."$0", $f);

if(strpos($g, "EXTM3U") !== false) {
echo $g;
} else {
$retry = "http://domain/star7.php?id=".$id."&e=.m3u8";
header("Location: ".$retry);
}

?>