<?php
//START TOKEN CODE BY KUTTYTV
    $getip = $_GET["Auth_IP"];
        $ipenc = explode("MKi", explode("&report=", $getip)[0])[1];
        $ipaddr = $ip=base64_decode($ipenc);
        $date = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
        $date = $date->format('Y-m-d H');
        $key = 'mhdpvtkey'; //KEEP IT IN SECRET
        $hashsrt = $ipaddr.$key.$date;
        $hash = sha1($hashsrt);
        
        $UA = $_SERVER['HTTP_USER_AGENT'];
        $UAS = explode("oxoo/1.0", explode("ExoPlayerLib/2.14.1", $UA)[0])[1];
        $UASC = 'oxoo/1.0' . $UAS . 'ExoPlayerLib/2.14.1';
        
        $tok1 = $hash."r!&Auth_IP=MKi".$ipenc."&port=1";
        $tok2 = $_GET["Auth_Token"]."&Auth_IP=".$_GET["Auth_IP"]."&port=1";
        
        $verify1 = $tok1.$UA;
        $verify2 = $tok2.$UASC;
    //END TOKEN CODE BY KUTTYTV


error_reporting(0);

header("Content-Type: application/vnd.apple.mpegurl");

$id = $_GET['id'];

$data = json_decode(file_get_contents("redbox_channels.json"), true);



foreach($data["channels_list"] as $keys => $values) {

	foreach ($values["stream_list"] as $stream) {

	    if ($stream["stream_id"] == $id) {

	        $blink = $stream["stream_url"];



$burl = str_replace("playlist.m3u8", "", $blink);

}}}

$opts = array(

  'http'=>array(

    'method'=>"GET",

    'header'=>"User-Agent: Dalvik/2.1.0 (Linux; U; Android 7.1.2; SM-G977N Build/LMY48Z)\r\n" .

              "authorization: Basic eWFyYXBuYWthYW1rYXJvOnR1bmduYWtpYWthcm8=\r\n"

  )

);



$context = stream_context_create($opts);

$basetoken = file_get_contents('http://135.181.2.111:8800/cip/4c.rbt/', false, $context);

$token = file_get_contents(base64_decode("aHR0cHM6Ly9pbmRzdHJlYW0ueHl6L3JlZGJveGFwaS5waHA=").$basetoken);


$pxy = "";
$link = $pxy.$blink.$token;

$e = file_get_contents($link);

preg_match("/(?=chunks.m3u8).*/", $e, $m);

$f = file_get_contents($pxy.$burl.$m[0]);

$g = preg_replace("/l_/", "https://mallutvapp.com/redbox/stream.php?Auth_Token=".$tok1."&stream=".$burl."l_", str_replace(".ts?", ".ts&", $f));

//if(strpos($g, "EXTM3U") !== false) {

//echo $g;


//} else {

//$relink = "https://mallutvapp.com/redbox/redbox.php?id=".$id."&e=.m3u8";

//header("Location: ".$relink);

//}
if($verify1 == $verify2){
    echo $g;
}else{
    echo "WATCH WITH MALLUTV";
}

?>