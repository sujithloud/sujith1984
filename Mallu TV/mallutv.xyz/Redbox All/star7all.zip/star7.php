<?php
   //START TOKEN CODE BY KUTTYTV
    $getip = $_GET["Auth_IP"];
        $ipenc = explode("MKi", explode("&report=", $getip)[0])[1];
        $ipaddr = $ip=base64_decode($ipenc);
        $date = new DateTime("now", new DateTimeZone('Asia/Kolkata'));
        $date = $date->format('Y-m-d H');
        $key = 'mhdpvtkey'; //KEEP IT IN SECRET
        $hashsrt = $ipaddr.$key.$date;
        $hash = sha1($hashsrt);
        
        $UA = $_SERVER['HTTP_USER_AGENT'];
        $UAS = explode("oxoo/1.0", explode("ExoPlayerLib/2.14.1", $UA)[0])[1];
        $UASC = 'oxoo/1.0' . $UAS . 'ExoPlayerLib/2.14.1';
        
        $tok1 = $hash."r!&Auth_IP=MKi".$ipenc."&port=1";
        $tok2 = $_GET["Auth_Token"]."&Auth_IP=".$_GET["Auth_IP"]."&port=1";
        
        $verify1 = $tok1.$UA;
        $verify2 = $tok2.$UASC;
    //END TOKEN CODE BY KUTTYTV

error_reporting(0);
header("content-type: application/vnd.apple.mpegurl");
header("pragma: no-cache");
header("Connection: keep-alive");
$id = $_GET['id'];
$opts = [
    "http" => [
        "method" => "GET",
        "header" => "User-Agent: REDLINECLIENT RED360 V0.1.49" 
    ]
];

$cx = stream_context_create($opts);

$json = json_decode(file_get_contents("starzz.json"), true);

foreach($json["channels_list"] as $v) {
	if($v['id'] == $id) {
		$url = $v['link'];
	}
}
$turl = "https://mallutv.xyz/tok.php";
$token=file_get_contents($turl);
$burl = $url;
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $burl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
$html = curl_exec($ch);
$baselink = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
curl_close($ch);
$burl = $pxy.$baselink;
$blink = preg_replace("/(?=index).*/", "", $burl);
$elink = preg_replace("/(?=index).*/", "", $baselink);
$flink = $blink."tracks-v1a1/mono.m3u8?".$token;
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"User-Agent: REDLINECLIENT RED360 V0.1.49"
  )
);
$context = stream_context_create($opts);
$e = file_get_contents($flink, false, $context);
$f = preg_replace("/(?<=ts).*/", "", $e);
$g = preg_replace("/(?=2022\/).*ts/", "https://mallutv.xyz/ts.php?ts=".$elink."tracks-v1a1/"."$0", $f);
if($verify1 == $verify2){

echo $g;

}else{
    echo "WATCH WITH MALLUTV";
}



?>