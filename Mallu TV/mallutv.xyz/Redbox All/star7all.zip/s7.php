<?php
$aa = "https://mallutv.xyz/token.txt";
$url = file_get_contents($aa);
echo $url;
?>