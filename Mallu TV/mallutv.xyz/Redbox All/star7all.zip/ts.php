<?php

error_reporting(0);
$opts = [
    "http" => [
        "method" => "GET",
        "header" => "User-Agent: REDLINECLIENT RED360 V0.1.49" 
    ]
];

$cx = stream_context_create($opts);

header("content-type: video/mp2t");
header("pragma: no-cache");
$ts = $_GET['ts'];
$tok=file_get_contents("https://mallutv.xyz/tok.php");
$url = $pxy.$ts."?".$tok;
$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"User-Agent: exoplayer\r\n"
  )
);
$context = stream_context_create($opts);
$e = file_get_contents($url, false, $context);

echo $e;

?>