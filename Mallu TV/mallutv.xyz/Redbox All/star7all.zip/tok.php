<?php
//set_time_limit(300);
$opts = [
    "http" => [
        "method" => "GET",
        "header" => "User-Agent: REDLINECLIENT GOLDENBOX V2.8.89" 
    ]
];

$cx = stream_context_create($opts);
//$rey="aHR0cDovL3JleWFuY2UwLndlYmQucHJvL21wLnBocC8=";
//$pxy= base64_decode($rey);
$url = ($pxy."http://access.richtv1.com/ch.php?usercode=9253365974&mac=3034D22F5022&customer=redline&check=887628454");
$a = file_get_contents($url,false,$cx);
$json = json_decode($a, true);
foreach($json as $values) {
    if ($values['id'] == '18184') {
        $base = $values['link'];
        $preg = preg_match("/token=.*"."/", $base, $match);
        $tok = str_replace("RED", "RED", $match[0]);
		//$maintoken=base64_encode($tok);
        echo $tok;
        //file_put_contents("/to.txt", $maintoken);
    }
}
file_put_contents("token.txt", $tok);

?>