<?php
header("Content-Type: application/vnd.apple.mpegurl");
  header("Access-Control-Expose-Headers: Content-Length,Content-Range");
  header("Access-Control-Allow-Headers: Range");
  header("Accept-Ranges: bytes");
  date_default_timezone_set('Asia/Kolkata');
  


$get = file_get_contents("a.json");
$de = json_decode($get);
$geturl = $de -> url ;
$url= ($geturl."master_2.m3u8");



  $curl = curl_init();
  $get = file_get_contents("a.json");
$de = json_decode($get);
$getcookie = $de -> cookie ;
$getrefer = $de -> refer ;
$getlink = $de -> url ;
$exp=explode("/",$getlink);
$host=$exp[2];
  curl_setopt_array($curl, array(
   CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
 "Accept: */*",
"Accept-Encoding: gzip, deflate, br",
"Accept-Language: en-US,en;q=0.9",
"Connection: keep-alive",
"Cookie: ".$getcookie,
"Host: ".$host,
"Origin: https://www.hotstar.com",
"Referer: ".$getrefer,
"Sec-Fetch-Dest: empty'",
"Sec-Fetch-Mode: cors'",
"Sec-Fetch-Site: same-site",
"User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36",
    ),
  ));
  
  $response = curl_exec($curl);
  $err = curl_error($curl);
  
  curl_close($curl);
  
  if ($err) {

    return "nok";
  } else {
   $hs = $response;
  }


   
    $hs= str_replace("master",'hstarstream.php?ts=master', $hs);
  


 echo $hs;



  
  ?>