<?php
header("Content-Type: application/vnd.apple.mpegurl");
echo '#EXTM3U'.PHP_EOL;
echo '#EXT-X-VERSION:3'.PHP_EOL;
echo '#EXT-X-STREAM-INF:PROGRAM-ID=1,CLOSED-CAPTIONS=NONE,BANDWIDTH=140p,RESOLUTION=140p'.PHP_EOL;
echo 'http://localhost/140p.php?e=.m3u8'.PHP_EOL;
echo '#EXT-X-STREAM-INF:PROGRAM-ID=1,CLOSED-CAPTIONS=NONE,BANDWIDTH=240p,RESOLUTION=240p'.PHP_EOL;
echo 'http://localhost/240p.php?e=.m3u8'.PHP_EOL;
echo '#EXT-X-STREAM-INF:PROGRAM-ID=1,CLOSED-CAPTIONS=NONE,BANDWIDTH=360p,RESOLUTION=360p'.PHP_EOL;
echo 'http://localhost/360p.php?e=.m3u8'.PHP_EOL;
echo '#EXT-X-STREAM-INF:PROGRAM-ID=1,CLOSED-CAPTIONS=NONE,BANDWIDTH=480p,RESOLUTION=480p'.PHP_EOL;
echo 'http://localhost/480p.php?e=.m3u8'.PHP_EOL;
echo '#EXT-X-STREAM-INF:PROGRAM-ID=1,CLOSED-CAPTIONS=NONE,BANDWIDTH=720p,RESOLUTION=720p'.PHP_EOL;
echo 'http://localhost/720p.php?e=.m3u8'.PHP_EOL;
echo '#EXT-X-STREAM-INF:PROGRAM-ID=1,CLOSED-CAPTIONS=NONE,BANDWIDTH=1080p,RESOLUTION=1080p'.PHP_EOL;
echo 'http://localhost/1080p.php?e=.m3u8'.PHP_EOL;


//Note :-http://localhost/ change kar lena apna site location se
?>