<?php
error_reporting(0);
header("Content-Type: application/vnd.apple.mpegurl");

$url = $_GET['url'];

$burl = str_replace("playlist.m3u8", "", $url);

$opts = array(
  'http'=>array(
    'method'=>"GET",
    'header'=>"User-Agent: Dalvik/2.1.0 (Linux; U; Android 7.1.2; SM-G977N Build/LMY48Z)\r\n" .
              "authorization: Basic eWFyYXBuYWthYW1rYXJvOnR1bmduYWtpYWthcm8=\r\n"
  )
);

$context = stream_context_create($opts);
$pxy=base64_decode("aHR0cDovLzEwMy4yMTUuMTQ5LjM0L21wLnBocC8=");
$basetoken = (file_get_contents($pxy.'http://echo.rapidstreams.io/at.rstrm/', true, $context));
$link = ($pxy.$url.$basetoken);
$base = file_get_contents($link, false);
$rey=base64_decode("aHR0cDovLzEwMy4yMTUuMTQ5LjM0L3JhcGlkLnBocD91cmw9");
preg_match("/(?=chunks.m3u8).*/", $base, $m);
$f = file_get_contents($burl.$m[0]);
$g=file_get_contents($rey.$url);
$a = preg_replace("/l_/", "rapidtv.php?stream=".$burl."l_", str_replace(".ts?", ".ts&", $f));
if(strpos($t, "EXTM3U") !== false) {
echo $g;
} else {
$try="domain/rapid.php?url=".$url."&e=.m3u8";
header("location:".$try);
}